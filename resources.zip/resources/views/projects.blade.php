@extends('layout')

@section('content')
    <h1 class="text-3xl font-bold">Our Projects</h1>
    <p>Coming soon...</p>
@endsection
