@extends('layouts.app')

@section('content')
<div class="min-h-screen bg-gradient-to-br from-blue-900 via-gray-900 to-black flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 overflow-hidden">
    <div class="relative max-w-md w-full space-y-8 bg-gray-800/90 p-6 sm:p-8 rounded-2xl shadow-2xl border border-blue-700/50 backdrop-blur-sm transform transition-all duration-300 hover:shadow-blue-500/20">
        <div class="absolute -top-4 -left-4 w-20 h-20 bg-blue-500/20 rounded-full blur-xl animate-pulse"></div>
        <div class="absolute -bottom-4 -right-4 w-24 h-24 bg-purple-500/20 rounded-full blur-xl animate-pulse delay-200"></div>

        <div class="text-center z-10">
            <h2 class="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400 mb-3 animate__animated animate__fadeInDown">
                Verify Your Email
            </h2>
            <p class="text-sm text-gray-300 mb-4">
                Thanks for registering with Mithila Tech at <strong>{{ now()->setTimezone('Asia/Kolkata')->format('h:i A T, l, F d, Y') }}</strong> 
            </p>
        </div>
        @if (session('resent'))
            <div class="text-sm text-green-400 text-center p-2 bg-green-500/10 rounded-lg">
                A fresh verification link has been sent to your email address.
            </div>
        @endif
        <div class="text-sm text-gray-300 text-center space-y-2">
            <p>Before proceeding, please check your email for a verification link.</p>
            <p>If you did not receive the email,
                <form class="d-inline" method="POST" action="{{ route('verification.resend') }}" data-aos="fade-up" data-aos-duration="1000">
                    @csrf
                    <button type="submit" class="font-medium text-blue-400 hover:text-blue-300 underline transition-colors duration-200 bg-transparent border-0 p-0 m-0">
                        click here to request another
                    </button>.
                </form>
            </p>
        </div>
    </div>
</div>
@endsection
