@extends('layouts.app')

@section('content')
    <div class="container mt-5">
        <h1>Apply for {{ $career->title ?? 'Job Title' }}</h1>
        <form action="{{ route('career.apply.submit', $career->slug ?? '') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="mb-3">
                <label for="resume" class="form-label">Resume (PDF only)</label>
                <input type="file" class="form-control" id="resume" name="resume" accept=".pdf" required>
            </div>
            <button type="submit" class="btn btn-primary">Submit Application</button>
        </form>
    </div>
@endsection
