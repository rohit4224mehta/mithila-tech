@extends('layouts.app')

@section('content')
    <div class="min-h-screen">
        <!-- Hero Section -->
        <section class="hero-gradient text-white section">
            <div class="container position-relative z-1">
                <div class="row align-items-center min-vh-70">
                    <div class="col-lg-8 mx-auto text-center">
                        <h1 class="display-4 fw-bold mb-4 animate__animated animate__fadeInDown">
                            {{ $pageTitle ?? 'Join Our Team' }}
                        </h1>
                        <p class="lead mb-5 animate__animated animate__fadeIn animate__delay-1s">
                            {{ $metaDescription ?? 'Build your future with Mithila Tech, where innovation meets career growth.' }}
                        </p>
                        <div class="animate__animated animate__fadeIn animate__delay-2s">
                            <a href="#openings" class="btn btn-primary btn-lg me-3 px-4 py-2">View Openings</a>
                            <a href="#culture" class="btn btn-outline-light btn-lg px-4 py-2">Our Culture</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Job Openings Section -->
        <section class="section bg-light" id="openings">
            <div class="container">
                <div class="text-center mb-5 animate__animated animate__fadeInDown">
                    <h2 class="section-title">{{ $openingsTitle ?? 'Current Opportunities' }}</h2>
                    <p class="lead text-muted">{{ $openingsDescription ?? 'Exciting roles waiting for talented individuals like you' }}</p>
                </div>

                <div class="row g-4">
                    @forelse ($careers ?? [] as $career)
                        <div class="col-md-6 animate__animated animate__fadeIn{{ $loop->even ? 'Left' : 'Right' }}" data-delay="{{ $loop->index * 200 }}">
                            <div class="card card-service h-100 border-0 shadow-sm rounded-3">
                                <div class="card-body p-4 d-flex flex-column">
                                    <div class="service-icon bg-gradient-tech rounded-circle mb-4 d-flex align-items-center justify-content-center" style="width: 80px; height: 80px;">
                                        <i class="{{ $career->icon ?? 'bi bi-briefcase' }} text-white fs-2"></i>
                                    </div>

                                    <h4 class="h5 mb-3 fw-semibold">{{ $career->title ?? 'Job Title' }}</h4>

                                    <div class="d-flex flex-wrap gap-2 mb-3">
                                        <span class="badge bg-primary text-white">{{ $career->location ?? 'Remote' }}</span>
                                        <span class="badge bg-success text-white">{{ $career->type ?? 'Full-time' }}</span>
                                        <span class="badge bg-info text-white">{{ $career->experience ?? '2+ years' }}</span>
                                    </div>

                                    <p class="text-muted mb-4">{{ Str::limit($career->description ?? 'Job description coming soon.', 150) }}</p>

                                    @php
                                        $benefits = is_string($career->benefits ?? null)
                                            ? json_decode($career->benefits, true)
                                            : ($career->benefits ?? []);
                                        if (!is_array($benefits)) $benefits = ['Competitive salary', 'Flexible hours'];
                                    @endphp

                                    <ul class="text-muted ps-4 mb-3">
                                        @foreach ($benefits as $benefit)
                                            <li class="mb-2">
                                                <i class="bi bi-check-circle-fill text-primary me-2"></i>
                                                {{ $benefit }}
                                            </li>
                                        @endforeach
                                    </ul>

                                    <a href="{{ route('career.apply', $career->slug ?? 'job-' . $loop->index) }}" class="btn btn-primary btn-sm mt-auto">Apply Now</a>
                                </div>
                            </div>
                        </div>
                    @empty
                        <div class="col-12 text-center">
                            <p class="text-muted">No job openings available at this time.</p>
                        </div>
                    @endforelse
                </div>
            </div>
        </section>

        <!-- Culture Section -->
        <section class="section" id="culture">
            <div class="container">
                <div class="text-center mb-5 animate__animated animate__fadeInDown">
                    <h2 class="section-title">{{ $cultureTitle ?? 'Our Work Culture' }}</h2>
                    <p class="lead text-muted">{{ $cultureDescription ?? 'What makes Mithila Tech special' }}</p>
                </div>

                <div class="row g-4">
                    @forelse ($cultureValues ?? [] as $value)
                        <div class="col-md-4 animate__animated animate__fadeInUp" data-delay="{{ $loop->index * 200 }}">
                            <div class="culture-card text-center p-4 h-100 border-0 shadow-sm rounded-3">
                                <div class="culture-icon bg-primary rounded-circle mb-4 d-flex align-items-center justify-content-center" style="width: 60px; height: 60px;">
                                    <i class="{{ $value->icon ?? 'bi bi-people-fill' }} text-white fs-4"></i>
                                </div>
                                <h4 class="h5 mb-3">{{ $value->title ?? 'Value' }}</h4>
                                <p class="text-muted">{{ $value->description ?? 'Description here' }}</p>
                            </div>
                        </div>
                    @empty
                        <div class="col-12 text-center">
                            <p class="text-muted">No culture values defined yet.</p>
                        </div>
                    @endforelse
                </div>
            </div>
        </section>

        <!-- Employee Testimonials -->
        <section class="section bg-light">
            <div class="container">
                <div class="text-center mb-5 animate__animated animate__fadeInDown">
                    <h2 class="section-title">{{ $testimonialsTitle ?? 'Hear From Our Team' }}</h2>
                    <p class="lead text-muted">{{ $testimonialsDescription ?? 'What our employees say about working at Mithila Tech' }}</p>
                </div>

                <div class="row g-4">
                    @forelse ($testimonials ?? [] as $testimonial)
                        <div class="col-md-6 animate__animated animate__fadeIn{{ $loop->even ? 'Left' : 'Right' }}" data-delay="{{ $loop->index * 200 }}">
                            <div class="testimonial-card border-0 shadow-sm rounded-3 p-4 h-100">
                                <div class="d-flex align-items-center mb-4">
                                    <img src="{{ $testimonial->image_url ?? asset('images/testimonial-placeholder.jpg') }}" alt="{{ $testimonial->name ?? 'Employee' }}" class="rounded-circle me-3" width="70" height="70">
                                    <div>
                                        <h5 class="mb-0 fw-semibold">{{ $testimonial->name ?? 'Anonymous' }}</h5>
                                        <small class="text-muted">{{ $testimonial->role ?? 'Team Member' }}, {{ $testimonial->tenure ?? '1 year' }} at Mithila Tech</small>
                                    </div>
                                </div>
                                <p class="mb-4">{{ $testimonial->content ?? '“A fantastic place to grow and learn!”' }}</p>
                                <div class="rating">
                                    @for ($i = 1; $i <= 5; $i++)
                                        <i class="{{ $i <= ($testimonial->rating ?? 5) ? 'bi bi-star-fill text-warning' : 'bi bi-star text-muted' }}"></i>
                                    @endfor
                                </div>
                            </div>
                        </div>
                    @empty
                        <div class="col-12 text-center">
                            <p class="text-muted">No testimonials available at this time.</p>
                        </div>
                    @endforelse
                </div>
            </div>
        </section>

        <!-- CTA Section -->
        <section class="section bg-gradient-tech text-white" id="apply">
            <div class="container text-center py-5">
                <h2 class="display-5 fw-bold mb-4 animate__animated animate__fadeInDown">{{ $ctaTitle ?? 'Ready for Your Next Challenge?' }}</h2>
                <p class="lead mb-5 animate__animated animate__fadeInUp">{{ $ctaDescription ?? 'Join a team that values your skills and helps you grow.' }}</p>
                <div class="animate__animated animate__zoomIn">
                    <a href="{{ route('contact') }}" class="btn btn-light btn-lg px-5 py-3 me-3">Apply Now</a>
                    <a href="#openings" class="btn btn-outline-light btn-lg px-5 py-3">View All Openings</a>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('styles')
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@700;800&display=swap');
@import url('https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css');

/* === Global Styles === */
:root {
    --primary-color: #1e40af;
    --secondary-color: #3b82f6;
    --light-color: #f9fafb;
    --gradient-tech: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
    --shadow-hover: 0 8px 25px rgba(0, 0, 0, 0.1);
    --border-radius: 0.75rem;
    --transition: all 0.3s ease;
}

body { font-family: 'Poppins', sans-serif; background-color: var(--light-color); color: #1e293b; }

.hero-gradient {
    position: relative;
    min-height: 70vh;
    background: var(--gradient-tech);
}
.hero-gradient::before {
    content: '';
    position: absolute;
    top: 0; left: 0; width: 100%; height: 100%;
    background: url('{{ asset('images/career-bg.jpg') }}') no-repeat center/cover;
    opacity: 0.2;
}
.card-service, .culture-card, .testimonial-card { background: #fff; border-radius: var(--border-radius); transition: var(--transition); }
.card-service:hover, .culture-card:hover, .testimonial-card:hover { transform: translateY(-8px); box-shadow: var(--shadow-hover); }
.bg-gradient-tech { background: var(--gradient-tech); }
.btn-primary { background: var(--gradient-tech); border: none; }
.btn-primary:hover { transform: translateY(-2px); box-shadow: var(--shadow-hover); }
</style>
@endpush

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', () => {
    const animateOnScroll = () => {
        document.querySelectorAll('.animate__animated:not(.animated)').forEach(el => {
            const top = el.getBoundingClientRect().top;
            if (top < window.innerHeight * 0.85) {
                const delay = parseInt(el.getAttribute('data-delay')) || 0;
                setTimeout(() => el.classList.add('animated', el.classList[1]), delay);
            }
        });
    };
    window.addEventListener('scroll', animateOnScroll);
    animateOnScroll();
});
</script>
@endpush
