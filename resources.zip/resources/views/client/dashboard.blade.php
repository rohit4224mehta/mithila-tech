@extends('layouts.app')

@section('content')
<div class="container mt-5">
    <h2 class="text-primary fw-bold mb-4">Client Dashboard - IT Solutions Hub</h2>
    <div class="row g-4">
        <!-- Profile Card -->
        <div class="col-md-4">
            <div class="card h-100 border-0 shadow-sm bg-glass">
                <div class="card-body text-center p-4">
                    <div class="profile-img-wrapper">
                        <img src="{{ auth()->user()->profile_picture ? asset('storage/profile_pictures/' . auth()->user()->profile_picture) : asset('images/default-avatar.png') }}" alt="Profile Picture" class="rounded-circle img-fluid mb-3" style="width: 150px; height: 150px; object-fit: cover;">
                    </div>
                    <h5 class="card-title text-dark mb-1">{{ auth()->user()->name }}</h5>
                    <p class="text-muted mb-2">{{ auth()->user()->email }}</p>
                    <p class="text-muted small">{{ auth()->user()->phone ?? 'Not provided' }}</p>
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#editProfileModal">
                    <i class="bi bi-pencil-fill me-1"></i> Edit Profile
                </button>
                </div>
            </div>
        </div>

        <!-- Edit Profile Modal -->
<div class="modal fade" id="editProfileModal" tabindex="-1" aria-labelledby="editProfileModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editProfileModalLabel">Edit Profile</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                @if (session('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        {{ session('success') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif
                @if ($errors->any())
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <ul class="mb-0">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif

                <form action="{{ route('client.profile.update') }}" method="POST" enctype="multipart/form-data" id="editProfileForm">
                    @csrf
                    <div class="mb-3">
                        <label for="profile_picture" class="form-label">Profile Picture</label>
                        <input type="file" class="form-control @error('profile_picture') is-invalid @enderror" id="profile_picture" name="profile_picture">
                        @if (auth()->user()->profile_picture)
                            <div class="mt-2">
                                <img src="{{ asset('storage/profile_pictures/' . auth()->user()->profile_picture) }}" alt="Current Profile Picture" class="rounded mt-2" style="max-width: 150px; max-height: 150px;">
                            </div>
                        @endif
                        @error('profile_picture')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" class="form-control @error('name') is-invalid @enderror" id="name" name="name" value="{{ old('name', auth()->user()->name) }}" required>
                        @error('name')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control @error('email') is-invalid @enderror" id="email" name="email" value="{{ old('email', auth()->user()->email) }}" required readonly>
                        @error('email')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="phone" class="form-label">Phone</label>
                        <input type="tel" class="form-control @error('phone') is-invalid @enderror" id="phone" name="phone" value="{{ old('phone', auth()->user()->phone) }}" required>
                        @error('phone')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>




                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" form="editProfileForm" class="btn btn-primary">Save Changes</button>
            </div>
        </div>
    </div>
</div>



        <!-- Stats Overview -->
        <div class="col-md-8">
            <div class="card border-0 shadow-sm bg-glass">
                <div class="card-body p-4">
                    <h5 class="card-title text-dark mb-4">Project Insights</h5>
                    <div class="row g-3">
                        <div class="col-6 col-md-4">
                            <div class="card h-100 bg-light-blue text-white p-3">
                                <h4 class="fw-bold">{{ $projectCount ?? 0 }}</h4>
                                <p class="mb-0">Active Projects</p>
                            </div>
                        </div>
                        <div class="col-6 col-md-4">
                            <div class="card h-100 bg-light-purple text-white p-3">
                                <h4 class="fw-bold">{{ $totalHours ?? 0 }} hrs</h4>
                                <p class="mb-0">Total Hours</p>
                            </div>
                        </div>
                        <div class="col-6 col-md-4">
                            <div class="card h-100 bg-light-orange text-white p-3">
                                <h4 class="fw-bold">{{ $pendingTasks ?? 0 }}</h4>
                                <p class="mb-0">Pending Tasks</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Project Progress Chart -->
    <div class="card border-0 shadow-sm bg-glass mt-4">
        <div class="card-body p-4">
            <h5 class="card-title text-dark mb-4">Project Progress Overview</h5>
            <div id="projectProgressChart" style="height: 300px;"></div>
        </div>
    </div>

    <!-- Recent Projects -->
    <div class="card border-0 shadow-sm bg-glass mt-4">
        <div class="card-body p-4">
            <h5 class="card-title text-dark mb-4">Recent Projects</h5>
            @if ($recentProjects->isNotEmpty())
                <div class="list-group list-group-flush">
                    @foreach ($recentProjects as $project)
                        <a href="{{ route('client.projects.show', $project->id) }}" class="list-group-item list-group-item-action bg-transparent text-dark">
                            <div class="d-flex w-100 justify-content-between align-items-center">
                                <h6 class="mb-0">{{ $project->name }}</h6>
                                <span class="badge @switch($project->status)
                                    @case('pending') bg-secondary
                                    @case('in_progress') bg-info
                                    @case('completed') bg-success
                                    @case('under_review') bg-warning
                                    @default bg-secondary
                                @endswitch">{{ ucfirst($project->status) }}</span>
                            </div>
                            <p class="mb-1 text-muted small">{{ \Illuminate\Support\Str::limit($project->description, 50) }}</p>
                            <small class="text-muted">Started: {{ $project->start_date->format('M d, Y') }}</small>
                        </a>
                    @endforeach
                </div>
                <a href="{{ route('client.projects') }}" class="btn btn-link text-primary mt-3">View All Projects</a>
            @else
                <p class="text-muted text-center">No recent projects available.</p>
            @endif
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="card border-0 shadow-sm bg-glass mt-4">
        <div class="card-body p-4">
            <h5 class="card-title text-dark mb-4">Quick Actions</h5>
            <div class="row g-3">
                <div class="col-md-4">
                    <a href="{{ route('client.projects') }}" class="card h-100 bg-light-blue text-white p-4 text-decoration-none text-center">
                        <i class="bi bi-gear-wide-connected fs-2 mb-2"></i>
                        <h6 class="mb-0">Manage Projects</h6>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="{{ route('contact') }}" class="card h-100 bg-light-purple text-white p-4 text-decoration-none text-center">
                        <i class="bi bi-headset fs-2 mb-2"></i>
                        <h6 class="mb-0">Contact Support</h6>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="{{ route('client.password.edit') }}" class="card h-100 bg-light-orange text-white p-4 text-decoration-none text-center">
                        <i class="bi bi-shield-lock fs-2 mb-2"></i>
                        <h6 class="mb-0">Change Password</h6>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('styles')
<style>
    .bg-glass {
        background: rgba(255, 255, 255, 0.9);
        backdrop-filter: blur(10px);
    }
    .bg-light-blue {
        background-color: #4dabf7;
    }
    .bg-light-purple {
        background-color: #a770ef;
    }
    .bg-light-orange {
        background-color: #ff8c42;
    }
    .card {
        border-radius: 1rem;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.2);
    }
    .profile-img-wrapper {
        overflow: hidden;
        border: 4px solid #4dabf7;
        border-radius: 50%;
        margin: 0 auto;
    }
    .badge {
        text-transform: capitalize;
        font-size: 0.9rem;
    }
    .text-primary {
        color: #4dabf7 !important;
    }
    @media (max-width: 767.98px) {
        .row > [class*="col-"] {
            flex: 0 0 100%;
            max-width: 100%;
        }
        .card-body {
            padding: 1.5rem;
        }
    }
</style>
@endpush

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function () {
    // Sample data for chart (replace with dynamic data from controller if available)
    const projectData = {
        labels: @json($recentProjects->pluck('name')),
        datasets: [{
            label: 'Progress (%)',
            data: @json($recentProjects->pluck('progress')),
            backgroundColor: ['#4dabf7', '#a770ef', '#ff8c42', '#6c757d'],
            borderWidth: 1
        }]
    };

    // Chart configuration
    const ctx = document.getElementById('projectProgressChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: projectData,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    title: {
                        display: true,
                        text: 'Progress (%)'
                    }
                }
            },
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                },
                title: {
                    display: true,
                    text: 'Project Progress'
                }
            }
        }
    });
});
</script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
@endpush
