@extends('layouts.app')

@section('content')
<div class="container mt-5">
    <h1 class="h3 mb-4 text-primary">Project Details: {{ $project->name }}</h1>
    <div class="card shadow-sm">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <p><strong>Client:</strong> {{ $project->client->name ?? 'Not assigned' }}</p>
                    <p><strong>Status:</strong> {{ ucfirst($project->status) }}</p>
                    <p><strong>Start Date:</strong> {{ $project->start_date->format('M d, Y') }}</p>
                    <p><strong>Deadline:</strong> {{ $project->deadline->format('M d, Y') }}</p>
                    <p><strong>Progress:</strong> {{ $project->progress }}%</p>
                    <p><strong>Hours:</strong> {{ $project->hours ?? 0 }} hrs</p>
                </div>
                <div class="col-md-6">
                    <p><strong>Description:</strong></p>
                    <p>{{ $project->description ?? 'No description available' }}</p>
                </div>
            </div>
            <div class="mt-4 text-end">
                <a href="{{ route('client.projects') }}" class="btn btn-secondary">Back to Projects</a>
            </div>
        </div>
    </div>
</div>
@endsection
