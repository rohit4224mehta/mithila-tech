@extends('layouts.employee_app')

@section('content')
    <div class="d-flex vh-100 bg-gradient" style="background: linear-gradient(135deg, #f1f5f9 0%, #e0e7ff 100%);">
        <div class="container-fluid py-4 flex-grow-1">
            <!-- Page Header -->
            <div class="page-header mb-4">
                <div class="row align-items-center">
                    <div class="col">
                        <h1 class="h2 fw-bold text-dark" style="color: #2c3e50;">Leave Requests</h1>
                        <p class="text-muted lead">Welcome back, {{ auth()->user()->name }}! Manage your leave requests here.</p>
                    </div>
                    
                </div>
            </div>

            <!-- Leave Requests Table -->
            <div class="card shadow-lg rounded-3 mb-5">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="card-title fw-semibold text-dark" style="color: #2c3e50;">Leave Requests List</h5>
                        <a href="{{ route('employee.leaves.index') }}" class="btn btn-sm btn-outline-primary">View All</a>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover table-striped">
                            <thead class="table-light">
                                <tr>
                                    <th class="py-3 text-dark" style="color: #2c3e50;">Leave Type</th>
                                    <th class="py-3 text-dark" style="color: #2c3e50;">Start Date</th>
                                    <th class="py-3 text-dark" style="color: #2c3e50;">End Date</th>
                                    <th class="py-3 text-dark" style="color: #2c3e50;">Status</th>
                                    <th class="py-3 text-dark" style="color: #2c3e50;">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($leaves as $leave)
                                    <tr>
                                        <td class="py-3">{{ $leave->leave_type }}</td>
                                        <td class="py-3">{{ $leave->start_date->format('M d, Y') }}</td>
                                        <td class="py-3">{{ $leave->end_date->format('M d, Y') }}</td>
                                        <td class="py-3">
                                            <span class="badge {{ $leave->status === 'approved' ? 'bg-success' : ($leave->status === 'pending' ? 'bg-warning text-dark' : 'bg-danger') }}">
                                                {{ ucfirst($leave->status) }}
                                            </span>
                                        </td>
                                        <td class="py-3">
                                            @if ($leave->status === 'pending')
                                                <a href="{{ route('employee.leaves.edit', $leave->id) }}" class="btn btn-sm btn-warning me-2">Edit</a>
                                                <form action="{{ route('employee.leaves.destroy', $leave->id) }}" method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to cancel this request?');">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-sm btn-danger">Cancel</button>
                                                </form>
                                            @else
                                                <a href="#" class="btn btn-sm btn-warning me-2" disabled>Edit</a>
                                                <a href="#" class="btn btn-sm btn-danger" disabled>Cancel</a>
                                            @endif
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="5" class="py-3 text-center">No leave requests found.</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Add New Leave Request Button -->
            <div class="text-center mb-5">
                <button class="btn btn-primary px-4 py-2 rounded-pill shadow-sm" data-bs-toggle="modal" data-bs-target="#addLeaveModal">
                    Request New Leave
                </button>
            </div>

            <!-- Add Leave Request Modal -->
            <div class="modal fade" id="addLeaveModal" tabindex="-1" aria-labelledby="addLeaveModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="addLeaveModalLabel">Request New Leave</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form id="addLeaveForm" action="{{ route('employee.leaves.store') }}" method="POST">
                                @csrf
                                <div class="mb-3">
                                    <label for="leaveType" class="form-label">Leave Type</label>
                                    <select class="form-control" id="leaveType" name="leave_type" required>
                                        <option value="">Select Leave Type</option>
                                        @foreach (['Sick Leave', 'Vacation', 'Personal Leave', 'Maternity/Paternity'] as $type)
                                            <option value="{{ $type }}">{{ $type }}</option>
                                        @endforeach
                                    </select>
                                    <span id="leave_typeError" class="error text-danger"></span>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="startDate" class="form-label">Start Date</label>
                                        <input type="date" class="form-control" id="startDate" name="start_date" min="{{ date('Y-m-d') }}" required>
                                        <span id="start_dateError" class="error text-danger"></span>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="endDate" class="form-label">End Date</label>
                                        <input type="date" class="form-control" id="endDate" name="end_date" min="{{ date('Y-m-d') }}" required>
                                        <span id="end_dateError" class="error text-danger"></span>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="reason" class="form-label">Reason</label>
                                    <textarea class="form-control" id="reason" name="reason" rows="4" required></textarea>
                                    <span id="reasonError" class="error text-danger"></span>
                                </div>
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="terms" name="terms" required>
                                    <label class="form-check-label" for="terms">I agree to the leave policy terms</label>
                                    <span id="termsError" class="error text-danger"></span>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" form="addLeaveForm" class="btn btn-primary">Submit Request</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('styles')
<style>
    :root {
        --primary-color: #2c3e50;
        --secondary-color: #34495e;
        --success-color: #10b981;
        --danger-color: #ef4444;
        --info-color: #3b82f6;
        --light-color: #f8fafc;
    }

    .bg-gradient {
        background-size: 200% 200%;
        animation: gradientAnimation 15s ease infinite;
    }

    @keyframes gradientAnimation {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }

    .card {
        border: none;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
    }

    .table-light th {
        background-color: #f8f9fa;
        color: var(--primary-color);
        font-weight: 600;
    }

    .modal-content {
        border-radius: 0.5rem;
    }

    .form-control:focus, .form-select:focus {
        border-color: #3b82f6;
        box-shadow: 0 0 0 0.2rem rgba(59, 130, 246, 0.25);
    }

    .is-invalid {
        border-color: #dc3545;
    }
    .is-valid {
        border-color: #28a745;
    }
    .error {
        display: none;
        font-size: 0.875rem;
    }

    @media (max-width: 768px) {
        .row > * {
            flex: 0 0 100%;
            max-width: 100%;
        }
        .table-responsive {
            min-width: 300px;
            overflow-x: auto;
        }
        h1 { font-size: 1.75rem; }
        .container-fluid { padding: 1rem; }
        .col-md-6 { margin-bottom: 1rem; }
        .d-flex.justify-content-between { flex-direction: column; gap: 1rem; }
        .btn { width: 100%; }
    }
</style>
@endpush

@push('scripts')
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Form Submission via AJAX
    const form = document.getElementById('addLeaveForm');
    form.addEventListener('submit', function(e) {
        e.preventDefault();

        $.ajax({
            url: form.action,
            type: 'POST',
            data: $(form).serialize(),
            success: function(response) {
                if (response.success) {
                    $('#addLeaveModal').modal('hide');
                    alert('Leave request submitted successfully!');
                    location.reload(); // Reload to reflect new data
                } else {
                    alert('Error: ' + (response.message || 'Please try again.'));
                }
            },
            error: function(xhr) {
                const errors = xhr.responseJSON.errors || {};
                $('#leave_typeError').text(errors.leave_type || '').toggle(!!errors.leave_type);
                $('#start_dateError').text(errors.start_date || '').toggle(!!errors.start_date);
                $('#end_dateError').text(errors.end_date || '').toggle(!!errors.end_date);
                $('#reasonError').text(errors.reason || '').toggle(!!errors.reason);
                $('#termsError').text(errors.terms || '').toggle(!!errors.terms);
                alert('Validation failed. Please check the form.');
            }
        });
    });

    // Date Validation
    const startDate = document.getElementById('startDate');
    const endDate = document.getElementById('endDate');
    startDate.addEventListener('change', function() {
        endDate.min = this.value;
    });
});
</script>
@endpush
