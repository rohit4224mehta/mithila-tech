@component('mail::message')
# Mithila Tech Email Verification

Hello {{ $user->name }},

Thank you for registering with Mithila Tech. Please verify your email address to activate your account.

@component('mail::button', ['url' => $url])
Verify Email Address
@endcomponent

This link is valid for 60 minutes. If you did not register, please ignore this email.

Thank you,  
Mithila Tech Team
@endcomponent