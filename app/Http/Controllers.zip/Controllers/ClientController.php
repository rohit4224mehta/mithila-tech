<?php

namespace App\Http\Controllers;

use App\Models\Insight;
use App\Models\Project;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;

class ClientController extends Controller
{
    /**
     * Constructor to apply authentication middleware for client-specific routes.
     */
    public function __construct()
    {
        $this->middleware('auth')->only([
            'dashboard', 'profile', 'editProfile', 'updateProfile', 'updateProfilePicture',
            'editPassword', 'updatePassword', 'projects', 'projectDetail'
        ]);
        $this->middleware('role:client')->only([
            'dashboard', 'profile', 'editProfile', 'updateProfile', 'updateProfilePicture',
            'editPassword', 'updatePassword', 'projects', 'projectDetail'
        ]);
    }

    /**
     * Display the home page.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        return view('home');
    }

    /**
     * Fetch the latest insights dynamically.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function getInsights(Request $request)
    {
        $insights = Insight::orderBy('created_at', 'desc')->take(3)->get(['id', 'title', 'content', 'image_url', 'created_at']);
        return response()->json(['success' => true, 'insights' => $insights]);
    }

    /**
     * Display the client dashboard with project statistics.
     *
     * @return \Illuminate\View\View
     */
    public function dashboard()
{
    $user = Auth::user();
    $projectCount = $user->ownedProjects()->where('status', 'active')->count();
    $totalHours = $user->ownedProjects()->sum('hours');
    $pendingTasks = 0; // Placeholder - Implement task logic if needed
    $recentProjects = $user->ownedProjects()->orderBy('start_date', 'desc')->take(5)->get();

    return view('client.dashboard', compact('projectCount', 'totalHours', 'pendingTasks', 'recentProjects'));
}

    /**
     * Display the client profile page.
     *
     * @return \Illuminate\View\View
     */
    public function profile()
    {
        if (!Auth::check()) {
            return redirect()->route('login')->with('error', 'Please log in to view your profile.');
        }

        $user = Auth::user();
        return view('client.profile', compact('user'));
    }

    /**
     * Display the edit profile form.
     *
     * @return \Illuminate\View\View
     */
    public function editProfile()
    {
        if (!Auth::check()) {
            return redirect()->route('login')->with('error', 'Please log in to edit your profile.');
        }

        $user = Auth::user();
        return view('client.profile_edit', compact('user'));
    }

    /**
     * Update client profile information.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function updateProfile(Request $request)
    {
        if (!Auth::check()) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . Auth::id(),
            'phone' => 'required|numeric|digits:10',
            'address' => 'nullable|string|max:255',
            'bio' => 'nullable|string|max:500',
            'profile_picture' => 'nullable|image|max:500',
        ]);

        $user = Auth::user();
        $user->update($request->only(['name', 'email', 'phone', 'address', 'bio']));

        if ($request->hasFile('profile_picture')) {
            $fileName = time() . '.' . $request->profile_picture->extension();
            $request->profile_picture->storeAs('public/profile_pictures', $fileName);
            if ($user->profile_picture) {
                Storage::delete('public/profile_pictures/' . $user->profile_picture);
            }
            $user->update(['profile_picture' => $fileName]);
        }

        return response()->json(['success' => true, 'message' => 'Profile updated successfully']);
    }

    /**
     * Update client profile picture.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function updateProfilePicture(Request $request)
    {
        if (!Auth::check()) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        $request->validate(['profile_picture' => 'required|image|max:500']);

        $user = Auth::user();
        if ($request->hasFile('profile_picture')) {
            $fileName = time() . '.' . $request->profile_picture->extension();
            $request->profile_picture->storeAs('public/profile_pictures', $fileName);
            if ($user->profile_picture) {
                Storage::delete('public/profile_pictures/' . $user->profile_picture);
            }
            $user->update(['profile_picture' => $fileName]);
        }

        return response()->json(['success' => true, 'profile_picture' => asset('storage/profile_pictures/' . $user->profile_picture)]);
    }

    /**
     * Display the change password form.
     *
     * @return \Illuminate\View\View
     */
    public function editPassword()
    {
        if (!Auth::check()) {
            return redirect()->route('login')->with('error', 'Please log in to change your password.');
        }

        return view('client.change_password');
    }

    /**
     * Update client password.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function updatePassword(Request $request)
{
    if (!Auth::check()) {
        return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
    }

    $request->validate([
        'current_password' => 'required',
        'new_password' => 'required|min:8|different:current_password|confirmed',
    ]);

    $user = Auth::user();
    if (!Hash::check($request->current_password, $user->password)) {
        return response()->json(['success' => false, 'message' => 'Current password is incorrect']);
    }

    $user->update(['password' => Hash::make($request->new_password)]);
    return response()->json(['success' => true, 'message' => 'Password updated successfully']);
}
    /**
     * Display the client's projects.
     *
     * @return \Illuminate\View\View
     */
    public function projects()
    {
        if (!Auth::check()) {
            return redirect()->route('login')->with('error', 'Please log in to view your projects.');
        }

        $user = Auth::user();
        $projects = $user->ownedProjects()
            ->orderBy('start_date', 'desc')
            ->paginate(10); // Adjust pagination as needed

        return view('client.projects', compact('projects'));
    }

    /**
     * Display details of a specific project.
     *
     * @param int $projectId
     * @return \Illuminate\View\View
     */
    public function projectDetail($projectId)
    {
        if (!Auth::check()) {
            return redirect()->route('login')->with('error', 'Please log in to view project details.');
        }

        $project = Project::with('client')->findOrFail($projectId);
        if ($project->client_id !== Auth::id()) {
            abort(403, 'Unauthorized action');
        }

        return view('client.project-detail', compact('project'));
    }

    /**
     * Placeholder for additional client-specific actions (e.g., contact form submission).
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function submitContactForm(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email',
            'message' => 'required|string|max:1000',
        ]);

        // Logic to store contact form data (e.g., in a 'contacts' table)
        // \App\Models\Contact::create($request->all());

        return response()->json(['success' => true, 'message' => 'Thank you for your message!']);
    }
}
