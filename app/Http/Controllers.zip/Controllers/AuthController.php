<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Employee;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\Rules;
use Illuminate\View\View;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;
use Illuminate\Auth\Events\Registered;

class AuthController extends Controller
{
    // Login Methods
    public function showLoginForm(): View
    {
        return view('auth.login');
    }

    public function login(Request $request): RedirectResponse
    {
        try {
            $request->validate([
                'email' => ['required', 'email'],
                'password' => ['required'],
            ]);

            $credentials = $request->only('email', 'password');

            if (Auth::attempt($credentials, $request->boolean('remember'))) {
                $user = Auth::user();
                if ($user->status === 'inactive') {
                    Auth::logout();
                    $request->session()->invalidate();
                    $request->session()->regenerateToken();
                    Log::warning('Login attempt by inactive user', ['email' => $user->email]);
                    return back()->withErrors(['email' => 'Please verify your email before logging in.']);
                }

                $user->update(['last_login_at' => now()]);
                Log::info("User {$user->email} logged in at " . now()->setTimezone('Asia/Kolkata')->format('h:i A T, l, F d, Y'));

                if ($user->role === 'admin') {
                    return redirect()->intended('/admin/dashboard');
                } elseif ($user->role === 'employee') {
                    return redirect()->intended('/employee/dashboard');
                } elseif ($user->role === 'client') {
                    return redirect()->intended('/client/dashboard');
                }
                return redirect()->intended('/dashboard');
            }

            Log::warning('Login attempt failed', ['email' => $request->email]);
            return back()->withErrors(['email' => 'The provided credentials do not match our records.']);
        } catch (\Exception $e) {
            Log::error('Login error', [
                'email' => $request->email,
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
            return back()->withErrors(['email' => 'An error occurred. Please try again.']);
        }
    }

    public function logout(Request $request): RedirectResponse
    {
        try {
            $email = Auth::user()->email ?? 'unknown';
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();
            Log::info("User {$email} logged out at " . now()->setTimezone('Asia/Kolkata')->format('h:i A T, l, F d, Y'));
            return redirect('/');
        } catch (\Exception $e) {
            Log::error('Logout error', [
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
            return redirect('/')->with('error', 'An error occurred during logout.');
        }
    }

    // Registration Methods
    public function showRegistrationForm(): View
    {
        return view('auth.register');
    }

    public function register(Request $request): RedirectResponse
    {
        try {
            $request->validate([
                'name' => ['required', 'string', 'max:255'],
                'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
                'password' => ['required', 'confirmed', Rules\Password::defaults()],
                'role' => ['required', 'in:admin,client,employee'],
            ]);

            $user = User::create([
                'name' => $request->name,
                'email' => $request->email,
                'password' => Hash::make($request->password),
                'role' => $request->role,
                'status' => 'inactive',
            ]);

            if ($request->role === 'employee') {
                Employee::create([
                    'user_id' => $user->id,
                    'employee_id' => 'EMP-' . str_pad($user->id, 5, '0', STR_PAD_LEFT),
                    'first_name' => $request->name,
                    'department' => 'N/A',
                    'join_date' => now()->toDateString(),
                ]);
            }

            event(new Registered($user));
            Auth::login($user);
            Log::info("User {$user->email} registered as {$user->role} at " . now()->setTimezone('Asia/Kolkata')->format('h:i A T, l, F d, Y'));

            return redirect()->route('verification.notice');
        } catch (\Exception $e) {
            Log::error('Registration error', [
                'email' => $request->email,
                'role' => $request->role,
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
            return back()->withErrors(['email' => 'An error occurred. Please try again.'])->withInput();
        }
    }

    // Email Verification Methods
    public function showVerificationNotice(): View
    {
        return Auth::check()
            ? view('auth.verify-email')
            : redirect()->route('login')->with('status', 'Please log in to verify your email.');
    }

    public function verify(Request $request, $id, $hash): RedirectResponse
    {
        try {
            $user = User::findOrFail($id);

            if (!hash_equals((string)$hash, sha1($user->getEmailForVerification()))) {
                Log::warning('Invalid email verification link', ['user_id' => $id]);
                return redirect()->route('login')->withErrors(['email' => 'Invalid verification link.']);
            }

            if (!$user->hasVerifiedEmail()) {
                $user->markEmailAsVerified();
                $user->update(['status' => 'active']);
                Log::info("User {$user->email} verified email and activated at " . now()->setTimezone('Asia/Kolkata')->format('h:i A T, l, F d, Y'));
            }

            return redirect()->route('login')->with('status', 'Email verified successfully! Please log in.');
        } catch (\Exception $e) {
            Log::error('Email verification error', [
                'user_id' => $id,
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
            return redirect()->route('login')->withErrors(['email' => 'An error occurred. Please try again.']);
        }
    }

    public function sendVerificationEmail(Request $request): RedirectResponse
    {
        try {
            $user = $request->user();
            if ($user->hasVerifiedEmail()) {
                Log::info("User {$user->email} attempted to resend verification but email already verified");
                return redirect()->intended('/dashboard')->with('status', 'Email already verified.');
            }

            $user->sendEmailVerificationNotification();
            Log::info("Verification email resent to {$user->email} at " . now()->setTimezone('Asia/Kolkata')->format('h:i A T, l, F d, Y'));

            return back()->with('status', 'verification-link-sent');
        } catch (\Exception $e) {
            Log::error('Verification email resend error', [
                'email' => $request->user()->email,
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
            return back()->withErrors(['email' => 'An error occurred. Please try again.']);
        }
    }

    // Forgot Password with OTP Methods
    public function showForgotPasswordForm(): View
    {
        return view('auth.forgot-password');
    }

    public function sendResetOtp(Request $request): RedirectResponse
    {
        try {
            $request->validate(['email' => 'required|email|exists:users']);

            $user = User::where('email', $request->email)->first();

            // Generate a 6-digit OTP
            $otp = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);

            // Store OTP in users table
            $user->update([
                'otp' => Hash::make($otp),
                'otp_expires_at' => now()->addMinutes(10),
            ]);

            // Log OTP for debugging in local environment only
            if (config('app.env') === 'local') {
                Log::debug('Generated OTP for password reset', ['email' => $user->email, 'otp' => $otp]);
            }

            // Send OTP via email (use queue if configured)
            if (config('mail.mailer') === 'queue') {
                Mail::queue('emails.otp', ['otp' => $otp, 'email' => $user->email], function ($message) use ($user) {
                    $message->to($user->email)
                            ->subject('Password Reset OTP - Mithila Tech')
                            ->from('support@mithilatech.com', 'Mithila Tech');
                });
            } else {
                Mail::send('emails.otp', ['otp' => $otp, 'email' => $user->email], function ($message) use ($user) {
                    $message->to($user->email)
                            ->subject('Password Reset OTP - Mithila Tech')
                            ->from('support@mithilatech.com', 'Mithila Tech');
                });
            }

            Log::info("OTP sent to {$user->email} at " . now()->setTimezone('Asia/Kolkata')->format('h:i A T, l, F d, Y'));

            return redirect()->route('password.reset.otp', ['email' => $user->email])
                           ->with('status', 'OTP sent to your email!');
        } catch (\Illuminate\Validation\ValidationException $e) {
            Log::warning('Password reset OTP validation failed', ['errors' => $e->errors()]);
            return back()->withErrors($e->errors())->withInput();
        } catch (\Swift_TransportException $e) {
            Log::error('Failed to send OTP email due to transport issue', [
                'email' => $request->email,
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
            return back()->withErrors(['email' => 'Failed to send OTP due to email server issues. Please try again later.'])->withInput();
        } catch (\Illuminate\Database\QueryException $e) {
            Log::error('Database error during OTP storage', [
                'email' => $request->email,
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
            return back()->withErrors(['email' => 'Failed to store OTP. Please contact support.'])->withInput();
        } catch (\Exception $e) {
            Log::error('Unexpected error in password reset OTP process', [
                'email' => $request->email,
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
            return back()->withErrors(['email' => 'An unexpected error occurred. Please try again.'])->withInput();
        }
    }

    public function showResetPasswordOtpForm(Request $request): View
    {
        $email = $request->query('email');
        if (!$email) {
            return redirect()->route('password.request')->withErrors(['email' => 'Email is required.']);
        }
        return view('auth.reset-password-otp', compact('email'));
    }

    public function resetPasswordWithOtp(Request $request): RedirectResponse
    {
        try {
            $request->validate([
                'email' => 'required|email|exists:users',
                'otp' => 'required|digits:6',
                'password' => ['required', 'confirmed', Rules\Password::defaults()],
            ]);

            $user = User::where('email', $request->email)->first();

            if (!$user->otp || !Hash::check($request->otp, $user->otp) || now()->gt($user->otp_expires_at)) {
                Log::warning('Invalid or expired OTP', ['email' => $request->email, 'otp' => $request->otp]);
                return back()->withErrors(['otp' => 'Invalid or expired OTP.'])->withInput();
            }

            // Update password and clear OTP
            $user->update([
                'password' => Hash::make($request->password),
                'otp' => null,
                'otp_expires_at' => null,
            ]);

            Log::info("User {$user->email} reset password with OTP at " . now()->setTimezone('Asia/Kolkata')->format('h:i A T, l, F d, Y'));

            return redirect()->route('login')->with('status', 'Password reset successfully! Please log in.');
        } catch (\Illuminate\Validation\ValidationException $e) {
            Log::warning('Password reset validation failed', ['errors' => $e->errors()]);
            return back()->withErrors($e->errors())->withInput();
        } catch (\Exception $e) {
            Log::error('Password reset error', [
                'email' => $request->email,
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
            return back()->withErrors(['otp' => 'An error occurred. Please try again.'])->withInput();
        }
    }
}
?>
