<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Schema;

use App\Models\Hero;
use App\Models\Vision;
use App\Models\Approach;
use App\Models\Step;
use App\Models\Building;
use App\Models\Offering;
use App\Models\Standout;
use App\Models\Strength;
use App\Models\WhoWeAre;
use App\Models\Founder;
use App\Models\Insight;
use App\Models\About;
use App\Models\Value;
use App\Models\Milestone;
use App\Models\TeamMember;
use App\Models\Service;
use App\Models\Testimonial;
use App\Models\Blog;
use App\Models\Career;
use App\Models\Media;
use App\Models\Process;
use App\Models\ProcessStep;
use App\Models\Cta;
use App\Models\Partner;
use App\Models\PartnerLogo;
use App\Models\ServicesOverview;
use App\Models\SolutionsOverview;
use App\Models\Solution;
use App\Models\CaseStudiesOverview;
use App\Models\CultureValue;
use App\Models\Application;
use App\Models\Contact;
use Illuminate\Support\Str;

/**
 * Class WelcomeController
 * Handles the main public-facing pages for Mithila Tech.
 * Last updated: Saturday, September 27, 2025, 06:25 PM IST
 */
class WelcomeController extends Controller
{
    public function index(Request $request)
    {
        try {
            $hero = Cache::remember('hero_home', 3600, fn() => Hero::where('page', 'home')->first() ?? (object)[
                'title' => 'Welcome to Mithila Tech',
                'subtitle' => 'Innovative IT Solutions',
                'background_image' => asset('images/hero-bg.jpg'),
                'call_to_action' => 'Get Started',
                'quote' => 'Empowering your future.',
                'focus_areas' => 'Innovation, Technology',
            ]);

            $vision = Cache::remember('vision_home', 3600, fn() => Vision::first() ?? (object)[]);
            $approach = Cache::remember('approach_home', 3600, fn() => Approach::first() ?? (object)[]);
            $steps = Cache::remember('steps_home', 3600, fn() => Step::orderBy('order')->get() ?? collect());
            $building = Cache::remember('building_home', 3600, fn() => Building::first() ?? (object)[]);
            $offerings = Cache::remember('offerings_home', 3600, fn() => Offering::orderBy('created_at', 'desc')->take(4)->get() ?? collect());
            $standout = Cache::remember('standout_home', 3600, fn() => Standout::first() ?? (object)[]);
            $strengths = Cache::remember('strengths_home', 3600, fn() => Strength::orderBy('created_at', 'desc')->take(3)->get() ?? collect());
            $whoWeAre = Cache::remember('who_we_are_home', 3600, fn() => WhoWeAre::first() ?? (object)[]);
            $founders = Cache::remember('founders_home', 3600, fn() => Founder::orderBy('created_at', 'desc')->take(2)->get() ?? collect());
            $insights = Cache::remember('insights_home', 3600, fn() => Insight::with('posts')->first() ?? (object)[]);

            View::share('pageTitle', 'Home - Mithila Tech');
            View::share('metaDescription', 'Explore Mithila Tech, a Nepal-based IT startup innovating with AI, NanoTech, and smart software solutions.');
            View::share('currentTime', now()->setTimezone('Asia/Kolkata')->format('g:i A T, F j, Y'));

            Log::info('Home page loaded', [
                'url' => $request->url(),
                'offerings_count' => $offerings->count(),
            ]);

            return view('home', compact(
                'hero', 'vision', 'approach', 'steps', 'building',
                'offerings', 'standout', 'strengths', 'whoWeAre', 'founders', 'insights'
            ));
        } catch (\Exception $e) {
            Log::error('Home page error', [
                'message' => $e->getMessage(),
                'user_id' => auth()->id() ?? 'guest',
                'url' => $request->url(),
                'trace' => $e->getTraceAsString(),
            ]);
            return view('errors.500');
        }
    }

    public function about(Request $request)
    {
        try {
            $aboutData = Cache::remember('about_page', 3600, fn() => About::first() ?? (object)[
                'image_url' => asset('images/mission.jpg'),
                'description' => 'Mithila Tech is a Nepal-based IT startup revolutionizing technology with innovative solutions.',
                'founded_year' => 2020,
                'team_size' => 50,
                'countries_served' => 10,
            ]);
            $values = Cache::remember('values_about', 3600, fn() => Value::orderBy('created_at', 'desc')->get() ?? collect([
                (object)['title' => 'Innovation', 'description' => 'Pushing technological boundaries.', 'icon' => 'bi-rocket'],
                (object)['title' => 'Integrity', 'description' => 'Building trust through transparency.', 'icon' => 'bi-shield-check'],
                (object)['title' => 'Excellence', 'description' => 'Delivering top-quality solutions.', 'icon' => 'bi-award'],
            ]));
            $milestones = Cache::remember('milestones_about', 3600, fn() => Milestone::orderBy('year', 'asc')->get() ?? collect([
                (object)['year' => 2020, 'title' => 'Founded', 'description' => 'Mithila Tech was established.'],
                (object)['year' => 2022, 'title' => 'First Major Client', 'description' => 'Signed our first international client.'],
                (object)['year' => 2025, 'title' => 'Global Expansion', 'description' => 'Expanded to 10 countries.'],
            ]));
            $teamMembers = Cache::remember('team_members_about', 3600, fn() => TeamMember::orderBy('created_at', 'desc')->take(6)->get() ?? collect([
                (object)['name' => 'John Doe', 'position' => 'CEO', 'image_url' => asset('images/team/john.jpg')],
                (object)['name' => 'Jane Smith', 'position' => 'CTO', 'image_url' => asset('images/team/jane.jpg')],
            ]));

            View::share('pageTitle', 'About Us - Mithila Tech');
            View::share('metaDescription', 'Learn about Mithila Tech\'s mission, vision, and team dedicated to delivering top-tier IT solutions.');
            View::share('currentTime', now()->setTimezone('Asia/Kolkata')->format('g:i A T, F j, Y'));

            Log::info('About page loaded', [
                'url' => $request->url(),
                'team_members_count' => $teamMembers->count(),
            ]);

            return view('about', compact('aboutData', 'values', 'milestones', 'teamMembers'));
        } catch (\Exception $e) {
            Log::error('About page error', [
                'message' => $e->getMessage(),
                'user_id' => auth()->id() ?? 'guest',
                'url' => $request->url(),
                'trace' => $e->getTraceAsString(),
            ]);
            return view('errors.500');
        }
    }

    public function services(Request $request)
    {
        try {
            $hero = Cache::remember('hero_services', 3600, fn() => Hero::where('page', 'services')->first() ?? (object)[
                'page' => 'services',
                'title' => 'Our Services',
                'subtitle' => 'Comprehensive IT solutions for your business.',
                'background_image' => asset('images/services-bg.jpg'),
                'call_to_action' => 'Explore Now',
                'quote' => 'Empowering your future.',
                'focus_areas' => 'Technology, Innovation',
            ]);

            $servicesOverview = Cache::remember('services_overview', 3600, fn() => ServicesOverview::first() ?? (object)[
                'badge' => 'Our Expertise',
                'title' => 'Our IT Services',
                'description' => 'Delivering cutting-edge IT solutions tailored to your needs.',
            ]);

            $services = Cache::remember('services_list', 3600, fn() => Service::where('status', 'active')->orderBy('created_at', 'desc')->take(6)->get() ?? collect([
                (object)[
                    'name' => 'Web Development',
                    'short_description' => 'Custom web solutions for your business.',
                    'icon' => 'bi-code-slash',
                    'slug' => 'web-development',
                    'status' => 'active',
                ],
                (object)[
                    'name' => 'AI Integration',
                    'short_description' => 'Implement AI to enhance operations.',
                    'icon' => 'bi-robot',
                    'slug' => 'ai-integration',
                    'status' => 'active',
                ],
                (object)[
                    'name' => 'Cloud Solutions',
                    'short_description' => 'Scalable and secure cloud services.',
                    'icon' => 'bi-cloud',
                    'slug' => 'cloud-solutions',
                    'status' => 'active',
                ],
            ]));

            $partners = Cache::remember('partners_services', 3600, fn() => Partner::with(['logos' => fn($query) => $query->orderBy('created_at', 'asc')])->first() ?? (object)[
                'badge' => 'Partners',
                'title' => 'Our Technology Partners',
                'description' => 'We collaborate with leading tech companies to deliver exceptional solutions.',
                'logos' => collect([
                    (object)['name' => 'AWS', 'image_url' => asset('images/partners/aws.png')],
                    (object)['name' => 'Google Cloud', 'image_url' => asset('images/partners/google-cloud.png')],
                    (object)['name' => 'Microsoft Azure', 'image_url' => asset('images/partners/azure.png')],
                ]),
            ]);

            $process = Cache::remember('process_services', 3600, fn() => Process::with(['steps' => fn($query) => $query->orderBy('order', 'asc')])->first() ?? (object)[
                'badge' => 'Our Approach',
                'title' => 'How We Work',
                'lead_description' => 'A streamlined process to deliver results.',
                'additional_description' => 'We follow a proven methodology to ensure success.',
                'steps' => collect([
                    (object)['title' => 'Discovery', 'description' => 'Understand client needs and goals.', 'order' => 1],
                    (object)['title' => 'Design', 'description' => 'Create tailored solutions.', 'order' => 2],
                    (object)['title' => 'Delivery', 'description' => 'Implement and support.', 'order' => 3],
                ]),
            ]);

            $cta = Cache::remember('cta_services', 3600, fn() => Cta::where('page', 'services')->first() ?? (object)[
                'page' => 'services',
                'title' => 'Ready to Transform?',
                'description' => 'Let’s build your future with our IT solutions.',
                'phone' => '+977-123-456-7890',
                'call_to_action' => 'Contact Us',
            ]);

            View::share('pageTitle', 'Services - Mithila Tech');
            View::share('metaDescription', 'Explore our comprehensive IT services at Mithila Tech.');
            View::share('currentTime', now()->setTimezone('Asia/Kolkata')->format('g:i A T, F j, Y'));

            Log::info('Services page loaded', [
                'url' => $request->url(),
                'services_count' => $services->count(),
                'partners_count' => isset($partners->logos) ? $partners->logos->count() : 0,
                'process_steps_count' => isset($process->steps) ? $process->steps->count() : 0,
            ]);

            return view('services', compact('hero', 'servicesOverview', 'services', 'partners', 'process', 'cta'));
        } catch (\Exception $e) {
            Log::error('Services page error', [
                'message' => $e->getMessage(),
                'user_id' => auth()->id() ?? 'guest',
                'url' => $request->url(),
                'trace' => $e->getTraceAsString(),
            ]);
            return view('errors.500');
        }
    }

    public function serviceDetail(Request $request, $slug)
    {
        try {
            $service = Cache::remember("service_{$slug}", 3600, fn() => Service::where('slug', $slug)->where('status', 'active')->firstOrFail());

            View::share('pageTitle', "{$service->name} - Mithila Tech");
            View::share('metaDescription', $service->short_description ? Str::limit($service->short_description, 160) : "Learn more about {$service->name} from Mithila Tech.");
            View::share('currentTime', now()->setTimezone('Asia/Kolkata')->format('g:i A T, F j, Y'));

            Log::info('Service detail page loaded', [
                'slug' => $slug,
                'url' => $request->url(),
            ]);

            return view('service-detail', compact('service'));
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            Log::error('Service not found', [
                'slug' => $slug,
                'user_id' => auth()->id() ?? 'guest',
                'url' => $request->url(),
            ]);
            return view('errors.404');
        } catch (\Exception $e) {
            Log::error('Service detail page error', [
                'message' => $e->getMessage(),
                'slug' => $slug,
                'user_id' => auth()->id() ?? 'guest',
                'url' => $request->url(),
                'trace' => $e->getTraceAsString(),
            ]);
            return view('errors.500');
        }
    }

    public function processDetail(Request $request)
    {
        try {
            $process = Cache::remember('process_detail', 3600, fn() => Process::with(['steps' => fn($query) => $query->orderBy('order', 'asc')])->first() ?? (object)[
                'badge' => 'Our Approach',
                'title' => 'Our Process',
                'lead_description' => 'A streamlined process to deliver results.',
                'additional_description' => 'We follow a proven methodology to ensure success.',
                'steps' => collect([
                    (object)['title' => 'Discovery', 'description' => 'Understand client needs and goals.', 'order' => 1],
                    (object)['title' => 'Design', 'description' => 'Create tailored solutions.', 'order' => 2],
                    (object)['title' => 'Delivery', 'description' => 'Implement and support.', 'order' => 3],
                ]),
            ]);

            View::share('pageTitle', 'Our Process - Mithila Tech');
            View::share('metaDescription', 'Learn about our proven methodology at Mithila Tech.');
            View::share('currentTime', now()->setTimezone('Asia/Kolkata')->format('g:i A T, F j, Y'));

            Log::info('Process detail page loaded', [
                'url' => $request->url(),
                'steps_count' => isset($process->steps) ? $process->steps->count() : 0,
            ]);

            return view('process-detail', compact('process'));
        } catch (\Exception $e) {
            Log::error('Process detail page error', [
                'message' => $e->getMessage(),
                'user_id' => auth()->id() ?? 'guest',
                'url' => $request->url(),
                'trace' => $e->getTraceAsString(),
            ]);
            return view('errors.500');
        }
    }

    public function solutions(Request $request)
    {
        try {
            $hero = Cache::remember('hero_solutions', 3600, fn() => Hero::where('page', 'solutions')->first() ?? (object)[
                'page' => 'solutions',
                'title' => 'Our Innovative Solutions',
                'subtitle' => 'Cutting-edge IT solutions to transform your business',
                'background_image' => asset('images/tech-bg.jpg'),
                'call_to_action' => 'Explore Solutions',
                'quote' => 'Transforming businesses with technology.',
                'focus_areas' => 'Innovation, Scalability',
            ]);

            $solutionsOverview = Cache::remember('solutions_overview', 3600, fn() => SolutionsOverview::first() ?? (object)[
                'badge' => 'Our Solutions',
                'title' => 'Our Solution Offerings',
                'description' => 'Tailored technology solutions for your business challenges',
            ]);

            $solutions = Cache::remember('solutions_list', 3600, fn() => Solution::where('status', 'published')->orderBy('created_at', 'desc')->take(6)->get() ?? collect([
                (object)[
                    'name' => 'Enterprise AI',
                    'description' => 'AI-driven solutions for enterprises.',
                    'slug' => 'enterprise-ai',
                    'status' => 'published',
                ],
                (object)[
                    'name' => 'Cloud Migration',
                    'description' => 'Seamless cloud migration services.',
                    'slug' => 'cloud-migration',
                    'status' => 'published',
                ],
                (object)[
                    'name' => 'Cybersecurity Suite',
                    'description' => 'Advanced security for your business.',
                    'slug' => 'cybersecurity-suite',
                    'status' => 'published',
                ],
            ]));

            $caseStudiesOverview = Cache::remember('case_studies_overview', 3600, fn() => CaseStudiesOverview::first() ?? (object)[
                'badge' => 'Case Studies',
                'title' => 'Our Success Stories',
                'description' => 'Real-world solutions delivering measurable results',
            ]);

            $testimonials = Cache::remember('testimonials_solutions', 3600, fn() => Testimonial::orderBy('created_at', 'desc')->take(3)->get() ?? collect([
                (object)[
                    'quote' => 'Mithila Tech transformed our business!',
                    'author' => 'John Doe',
                    'company' => 'Example Corp',
                ],
                (object)[
                    'quote' => 'Outstanding solutions and support.',
                    'author' => 'Jane Smith',
                    'company' => 'Tech Ltd',
                ],
            ]));

            $cta = Cache::remember('cta_solutions', 3600, fn() => Cta::where('page', 'solutions')->first() ?? (object)[
                'page' => 'solutions',
                'title' => 'Ready to Transform Your Business?',
                'description' => 'Let’s discuss how our solutions can drive your digital transformation',
                'phone' => '+977-123-456-7890',
                'call_to_action' => 'Contact Us',
            ]);

            View::share('pageTitle', 'Solutions - Mithila Tech');
            View::share('metaDescription', 'Explore Mithila Tech\'s innovative IT solutions for digital transformation.');
            View::share('currentTime', now()->setTimezone('Asia/Kolkata')->format('g:i A T, F j, Y'));

            Log::info('Solutions page loaded', [
                'url' => $request->url(),
                'solutions_count' => $solutions->count(),
                'testimonials_count' => $testimonials->count(),
            ]);

            return view('solutions', compact('hero', 'solutionsOverview', 'solutions', 'caseStudiesOverview', 'testimonials', 'cta'));
        } catch (\Exception $e) {
            Log::error('Solutions page error', [
                'message' => $e->getMessage(),
                'user_id' => auth()->id() ?? 'guest',
                'url' => $request->url(),
                'trace' => $e->getTraceAsString(),
            ]);
            return view('errors.500');
        }
    }

    public function showSolution(Request $request, $slug)
    {
        try {
            $solution = Cache::remember("solution_{$slug}", 3600, fn() => Solution::where('slug', $slug)->where('status', 'published')->firstOrFail());

            View::share('pageTitle', "{$solution->name} - Mithila Tech");
            View::share('metaDescription', $solution->description ? Str::limit($solution->description, 160) : "Learn more about {$solution->name} from Mithila Tech.");
            View::share('currentTime', now()->setTimezone('Asia/Kolkata')->format('g:i A T, F j, Y'));

            Log::info('Solution detail page loaded', [
                'slug' => $slug,
                'url' => $request->url(),
            ]);

            return view('solution-detail', compact('solution'));
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            Log::error('Solution not found', [
                'slug' => $slug,
                'user_id' => auth()->id() ?? 'guest',
                'url' => $request->url(),
            ]);
            return view('errors.404');
        } catch (\Exception $e) {
            Log::error('Solution detail page error', [
                'message' => $e->getMessage(),
                'slug' => $slug,
                'user_id' => auth()->id() ?? 'guest',
                'url' => $request->url(),
                'trace' => $e->getTraceAsString(),
            ]);
            return view('errors.500');
        }
    }

    public function media(Request $request)
    {
        try {
            $highlights = Cache::remember('media_highlights', 3600, fn() => Media::where('type', 'highlight')->where('status', 'published')->orderBy('published_at', 'desc')->take(6)->get() ?? collect());
            $pressReleases = Cache::remember('media_press_releases', 3600, fn() => Media::where('type', 'press_release')->where('status', 'published')->orderBy('published_at', 'desc')->take(6)->get() ?? collect());

            View::share('pageTitle', 'Media - Mithila Tech');
            View::share('metaDescription', 'View the latest news, press releases, and media coverage from Mithila Tech.');
            View::share('currentTime', now()->setTimezone('Asia/Kolkata')->format('g:i A T, F j, Y'));

            Log::info('Media page loaded', [
                'url' => $request->url(),
                'highlights_count' => $highlights->count(),
                'press_releases_count' => $pressReleases->count(),
            ]);

            return view('media', compact('highlights', 'pressReleases'));
        } catch (\Exception $e) {
            Log::error('Media page error', [
                'message' => $e->getMessage(),
                'user_id' => auth()->id() ?? 'guest',
                'url' => $request->url(),
                'trace' => $e->getTraceAsString(),
            ]);
            return view('errors.500');
        }
    }

    public function blog(Request $request)
    {
        try {
            $posts = Cache::remember('blog_posts', 3600, fn() => Blog::where('status', 'published')->orderBy('created_at', 'desc')->paginate(9));
            View::share('pageTitle', 'Blog - Mithila Tech');
            View::share('metaDescription', 'Read the latest news and tech trends from Mithila Tech.');
            View::share('currentTime', now()->setTimezone('Asia/Kolkata')->format('g:i A T, F j, Y'));

            Log::info('Blog page loaded', ['url' => $request->url(), 'posts_count' => $posts->count()]);

            return view('blog', compact('posts'));
        } catch (\Exception $e) {
            Log::error('Blog page error', [
                'message' => $e->getMessage(),
                'user_id' => auth()->id() ?? 'guest',
                'url' => $request->url(),
                'trace' => $e->getTraceAsString(),
            ]);
            return view('errors.500');
        }
    }

    public function showBlog(Request $request, $slug)
    {
        try {
            $post = Cache::remember("blog_post_{$slug}", 3600, fn() => Blog::where('slug', $slug)->where('status', 'published')->firstOrFail());
            View::share('pageTitle', "{$post->title} - Mithila Tech");
            View::share('metaDescription', $post->excerpt ? Str::limit($post->excerpt, 160) : "Read more about {$post->title} from Mithila Tech.");
            View::share('currentTime', now()->setTimezone('Asia/Kolkata')->format('g:i A T, F j, Y'));

            Log::info('Blog post page loaded', ['url' => $request->url(), 'slug' => $slug]);

            return view('blog-detail', compact('post'));
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            Log::error('Blog post not found', [
                'slug' => $slug,
                'user_id' => auth()->id() ?? 'guest',
                'url' => $request->url(),
            ]);
            return view('errors.404');
        } catch (\Exception $e) {
            Log::error('Blog post page error', [
                'message' => $e->getMessage(),
                'user_id' => auth()->id() ?? 'guest',
                'url' => $request->url(),
                'trace' => $e->getTraceAsString(),
            ]);
            return view('errors.500');
        }
    }

    public function showCategory(Request $request, $category)
    {
        try {
            $posts = Cache::remember("blog_category_{$category}", 3600, fn() => Blog::where('category', $category)
                ->where('status', 'published')
                ->orderBy('created_at', 'desc')
                ->paginate(9));
            View::share('pageTitle', ucwords(str_replace('-', ' ', $category)) . ' - Mithila Tech Blog');
            View::share('metaDescription', "Explore our latest blog posts on " . ucwords(str_replace('-', ' ', $category)) . ".");
            View::share('currentTime', now()->setTimezone('Asia/Kolkata')->format('g:i A T, F j, Y'));

            Log::info('Blog category page loaded', ['url' => $request->url(), 'category' => $category, 'posts_count' => $posts->count()]);

            return view('blog', compact('posts', 'category'));
        } catch (\Exception $e) {
            Log::error('Blog category page error', [
                'message' => $e->getMessage(),
                'user_id' => auth()->id() ?? 'guest',
                'url' => $request->url(),
                'trace' => $e->getTraceAsString(),
            ]);
            return view('errors.404');
        }
    }

    public function subscribe(Request $request)
    {
        try {
            $request->validate([
                'email' => 'required|email|max:255',
            ]);

            // Example: Store subscription (add logic to save to DB or send to email service)
            Log::info('New blog subscription', ['email' => $request->email]);

            return redirect()->route('blog')->with('success', 'Thank you for subscribing!');
        } catch (\Illuminate\Validation\ValidationException $e) {
            Log::warning('Subscription validation failed', ['errors' => $e->errors()]);
            return redirect()->route('blog')->withErrors($e->errors());
        } catch (\Exception $e) {
            Log::error('Error processing subscription: ' . $e->getMessage(), [
                'user_id' => auth()->id() ?? 'guest',
                'url' => $request->url(),
                'trace' => $e->getTraceAsString(),
            ]);
            return redirect()->route('blog')->with('error', 'An error occurred. Please try again.');
        }
    }


   public function careers(Request $request)
{
    try {
        // ✅ If your careers table has no "status" column, remove 'where' filter
        $careers = Cache::remember('careers_list', 3600, function () {
            if (Schema::hasColumn('careers', 'status')) {
                return Career::where('status', 'open')->orderBy('created_at', 'desc')->get();
            } else {
                return Career::orderBy('created_at', 'desc')->get();
            }
        });

        $cultureValues = Cache::remember('culture_values_list', 3600, fn() =>
            CultureValue::orderBy('created_at', 'asc')->get() ?? collect([
                (object)['title' => 'Collaboration', 'description' => 'Teamwork makes the dream work.', 'icon' => 'bi-people-fill'],
                (object)['title' => 'Innovation', 'description' => 'Always pushing boundaries.', 'icon' => 'bi-lightbulb'],
            ])
        );

        $testimonials = Cache::remember('testimonials_careers_list', 3600, fn() =>
            Testimonial::orderBy('created_at', 'desc')->take(3)->get() ?? collect([
                (object)['quote' => 'Great place to work!', 'author' => 'Employee A', 'company' => 'Mithila Tech'],
                (object)['quote' => 'Innovative environment.', 'author' => 'Employee B', 'company' => 'Mithila Tech'],
            ])
        );

        View::share('pageTitle', 'Careers - Mithila Tech');
        View::share('metaDescription', 'Join Mithila Tech! Explore exciting career opportunities in the IT industry.');
        View::share('openingsTitle', 'Current Opportunities');
        View::share('openingsDescription', 'Exciting roles waiting for talented individuals like you');
        View::share('cultureTitle', 'Our Work Culture');
        View::share('cultureDescription', 'What makes Mithila Tech special');
        View::share('testimonialsTitle', 'Hear From Our Team');
        View::share('testimonialsDescription', 'What our employees say about working at Mithila Tech');
        View::share('ctaTitle', 'Ready for Your Next Challenge?');
        View::share('ctaDescription', 'Join a team that values your skills and helps you grow');
        View::share('currentTime', now()->setTimezone('Asia/Kolkata')->format('g:i A T, F j, Y'));

        Log::info('Careers page loaded', [
            'url' => $request->url(),
            'careers_count' => $careers->count(),
            'culture_values_count' => $cultureValues->count(),
            'testimonials_count' => $testimonials->count(),
        ]);

        return view('careers', compact('careers', 'cultureValues', 'testimonials'));

    } catch (\Exception $e) {
        Log::error('Careers page error', [
            'message' => $e->getMessage(),
            'user_id' => auth()->id() ?? 'guest',
            'url' => $request->url(),
            'trace' => $e->getTraceAsString(),
        ]);
        return view('errors.500');
    }
}


    public function careerApply(Request $request, $slug)
    {
        try {
            $career = Cache::remember("career_{$slug}", 3600, fn() => Career::where('slug', $slug)->where('status', 'open')->firstOrFail());
            View::share('pageTitle', "Apply for {$career->title} - Mithila Tech");
            View::share('metaDescription', "Apply for the {$career->title} position at Mithila Tech.");
            View::share('currentTime', now()->setTimezone('Asia/Kolkata')->format('g:i A T, F j, Y'));

            Log::info('Career apply page loaded', ['url' => $request->url(), 'slug' => $slug]);

            return view('career-apply', compact('career'));
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            Log::error('Career not found', [
                'slug' => $slug,
                'user_id' => auth()->id() ?? 'guest',
                'url' => $request->url(),
            ]);
            return view('errors.404');
        } catch (\Exception $e) {
            Log::error('Career apply page error', [
                'message' => $e->getMessage(),
                'user_id' => auth()->id() ?? 'guest',
                'url' => $request->url(),
                'trace' => $e->getTraceAsString(),
            ]);
            return view('errors.500');
        }
    }

    public function submitCareerApplication(Request $request, $slug)
    {
        try {
            $career = Cache::remember("career_{$slug}", 3600, fn() => Career::where('slug', $slug)->where('status', 'open')->firstOrFail());
            $request->validate([
                'name' => 'required|string|max:255',
                'email' => 'required|email|max:255',
                'resume' => 'required|file|mimes:pdf|max:2048',
            ]);

            $path = $request->file('resume')->store('resumes', 'public');

            Application::create([
                'career_id' => $career->id,
                'name' => $request->name,
                'email' => $request->email,
                'resume_path' => $path,
            ]);

            Log::info('Career application submitted', [
                'career_id' => $career->id,
                'name' => $request->name,
                'email' => $request->email,
                'resume_path' => $path,
            ]);

            return redirect()->route('careers')->with('success', 'Application submitted successfully!');
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            Log::error('Career not found for application', [
                'slug' => $slug,
                'user_id' => auth()->id() ?? 'guest',
                'url' => $request->url(),
            ]);
            return back()->with('error', 'Job opening not found.');
        } catch (\Illuminate\Validation\ValidationException $e) {
            Log::warning('Career application validation failed', ['errors' => $e->errors()]);
            return back()->withErrors($e->errors())->withInput();
        } catch (\Exception $e) {
            Log::error('Career application error', [
                'message' => $e->getMessage(),
                'user_id' => auth()->id() ?? 'guest',
                'slug' => $slug,
                'url' => $request->url(),
                'trace' => $e->getTraceAsString(),
            ]);
            return back()->with('error', 'Failed to submit application. Please try again.');
        }
    }

    public function global(Request $request)
    {
        try {
            View::share('pageTitle', 'Global Presence - Mithila Tech');
            View::share('metaDescription', 'Discover Mithila Tech\'s global reach and offices worldwide.');
            View::share('currentTime', now()->setTimezone('Asia/Kolkata')->format('g:i A T, F j, Y'));

            Log::info('Global presence page loaded', ['url' => $request->url()]);

            return view('global');
        } catch (\Exception $e) {
            Log::error('Global presence page error', [
                'message' => $e->getMessage(),
                'user_id' => auth()->id() ?? 'guest',
                'url' => $request->url(),
                'trace' => $e->getTraceAsString(),
            ]);
            return view('errors.500');
        }
    }

    public function contact(Request $request)
    {
        try {
            View::share('pageTitle', 'Contact Us - Mithila Tech');
            View::share('metaDescription', 'Get in touch with Mithila Tech for support or inquiries. We\'re here to help!');
            View::share('currentTime', now()->setTimezone('Asia/Kolkata')->format('g:i A T, F j, Y'));

            Log::info('Contact page loaded', ['url' => $request->url()]);

            return view('contact');
        } catch (\Exception $e) {
            Log::error('Contact page error', [
                'message' => $e->getMessage(),
                'user_id' => auth()->id() ?? 'guest',
                'url' => $request->url(),
                'trace' => $e->getTraceAsString(),
            ]);
            return view('errors.500');
        }
    }

    public function submitContact(Request $request)
    {
        try {
            $validated = $request->validate([
                'name' => 'required|string|min:3|max:255|regex:/^[a-zA-Z\s]+$/',
                'email' => 'required|email|max:255',
                'subject' => 'required|string|max:255',
                'message' => 'required|string',
                'consent' => 'required|accepted',
            ]);

            Contact::create([
                'name' => $request->name,
                'email' => $request->email,
                'subject' => $request->subject,
                'message' => $request->message,
            ]);

            Log::info('Contact form submitted', [
                'email' => $request->email,
                'user_id' => auth()->id() ?? 'guest',
                'url' => $request->url(),
            ]);

            return redirect()->route('contact')->with('success', 'Thank you for your message! We will get back to you within 24 hours.');
        } catch (\Illuminate\Validation\ValidationException $e) {
            Log::warning('Contact form validation failed', [
                'errors' => $e->errors(),
                'url' => $request->url(),
            ]);
            return redirect()->route('contact')->withErrors($e->errors())->withInput();
        } catch (\Exception $e) {
            Log::error('Contact form error', [
                'message' => $e->getMessage(),
                'user_id' => auth()->id() ?? 'guest',
                'url' => $request->url(),
                'trace' => $e->getTraceAsString(),
            ]);
            return redirect()->route('contact')->with('error', 'An error occurred. Please try again.');
        }
    }

    public function terms(Request $request)
    {
        try {
            View::share('pageTitle', 'Terms & Conditions - Mithila Tech');
            View::share('metaDescription', 'Review the terms and conditions of using Mithila Tech\'s services.');
            View::share('currentTime', now()->setTimezone('Asia/Kolkata')->format('g:i A T, F j, Y'));

            Log::info('Terms page loaded', ['url' => $request->url()]);

            return view('terms');
        } catch (\Exception $e) {
            Log::error('Terms page error', [
                'message' => $e->getMessage(),
                'user_id' => auth()->id() ?? 'guest',
                'url' => $request->url(),
                'trace' => $e->getTraceAsString(),
            ]);
            return view('errors.500');
        }
    }

    public function privacy(Request $request)
    {
        try {
            View::share('pageTitle', 'Privacy Policy - Mithila Tech');
            View::share('metaDescription', 'Learn about Mithila Tech\'s privacy policy and how we protect your data.');
            View::share('currentTime', now()->setTimezone('Asia/Kolkata')->format('g:i A T, F j, Y'));

            Log::info('Privacy page loaded', ['url' => $request->url()]);

            return view('privacy');
        } catch (\Exception $e) {
            Log::error('Privacy page error', [
                'message' => $e->getMessage(),
                'user_id' => auth()->id() ?? 'guest',
                'url' => $request->url(),
                'trace' => $e->getTraceAsString(),
            ]);
            return view('errors.500');
        }
    }

    public function support(Request $request)
    {
        try {
            View::share('pageTitle', 'Support - Mithila Tech');
            View::share('metaDescription', 'Access support resources and assistance from Mithila Tech\'s team.');
            View::share('currentTime', now()->setTimezone('Asia/Kolkata')->format('g:i A T, F j, Y'));

            Log::info('Support page loaded', ['url' => $request->url()]);

            return view('support');
        } catch (\Exception $e) {
            Log::error('Support page error', [
                'message' => $e->getMessage(),
                'user_id' => auth()->id() ?? 'guest',
                'url' => $request->url(),
                'trace' => $e->getTraceAsString(),
            ]);
            return view('errors.500');
        }
    }
}
?>
